 import java.security.SecureRandom;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Arrays;
import java.util.Scanner;
import Lab9.Sec.JLSecurity;

public class Lab9TUI {
	private static Connection con;
	private static SecureRandom random = new SecureRandom();
	private static JLSecurity sec = new JLSecurity();
	private static String user, pass;
	private static Scanner scanner = new Scanner(System.in);
	public static void main(String[] args) {
		try{
			con = getConnection();
		}
		catch (SQLException s){
			System.out.println(s.getMessage());
		}
		showPrompt();
	}
	
	public static Connection getConnection() throws SQLException {
		Connection conn = null;
		//String sqlUrl = "jdbc:oracle:thin:@198.168.52.73:1521:orad11g";
		String sqlUrl = "jdbc:oracle:thin:@localhost:1521:xe";
		conn = DriverManager.getConnection(sqlUrl,"system", "SQLpass");
		System.out.println("Connected to database");
		return conn;
	}
	
	public static void showPrompt(){
		int choice = 0;
		System.out.println("\tWelcome to Bankruptster!");
		System.out.println("1. Login");
		System.out.println("2. Create new user");
		System.out.print("Please enter your choice: ");
		choice = scanner.nextInt();
		switch (choice){
			case 1: login();
					 break;
			
			case 2: createNewUser();
					 break;
			
			default:
					showPrompt();
					break;
		}
		
	}
	public static void login() {
		System.out.println("\t=====Login=====");
		System.out.print("Enter your userID: ");
		user = scanner.next();
		System.out.print("\nEnter your password: ");
		pass = scanner.next();
		
		/* Validate user input */
		if (user.isEmpty() || pass.isEmpty())
			throw new IllegalArgumentException("The username or password cannot be empty");
		
		/*Validate user credentials */
		String salt = "",
			   userID = "";
		byte[] hash = null,
			   tempHash = null;
		boolean result = false;
		String select = "SELECT USERID, HASH, SALT FROM CREDENTIALS WHERE USERID = \'" + user + "\'";
		
		try{
			Statement statement = con.createStatement();
			ResultSet rs = statement.executeQuery(select);
			rs.next();
			userID = rs.getString("USERID");
			tempHash = rs.getBytes("HASH");
			salt = rs.getString("SALT");
			rs.close();
		}
		catch (SQLException s){
			System.out.println(s.getMessage());
		}
		/* If salt == "" there is no user */
		if (salt.isEmpty())
			result = false;
		/* If the salt exists, hash the password and compare with parameter */
	
		else{
			hash = sec.hash(pass, salt);
			if (Arrays.equals(hash, tempHash))
				showScreen();
		}
		
		//System.out.println("Valid user?: " + result);
	}
	
	public static void createNewUser (){
		System.out.println("\t=====Create new user=====");
		System.out.print("Enter your userID: ");
		user = scanner.next();
		System.out.print("\nEnter your password: ");
		pass = scanner.next();
		
		/* Validate user input */
		if (user.isEmpty() || pass.isEmpty())
			throw new IllegalArgumentException("The username or password cannot be empty");
		
		/* Create the user */
		String insert = "INSERT INTO CREDENTIALS (USERID, HASH, SALT) VALUES (?, ?, ?)";
		String salt = sec.getSalt();
		byte[] hash = sec.hash(pass, salt);
		try{
			PreparedStatement statement = con.prepareStatement(insert);
			
			/* Set parameters */
			statement.setString(1, user);
			statement.setBytes(2, hash);
			statement.setString(3, salt);
			
			/*Execute statement */
			statement.execute();
		}
		catch(SQLException s){
			System.out.println(s.getMessage());
		}
		
	}
	
	public static void showScreen(){
		int choice = 0;
		System.out.println("\tWelcome to Bankruptster!");
		System.out.println("1. Search for movie by genre");
		System.out.println("2. Search for movie by title");
		System.out.println("3. Search for movie by actor/actress");
		System.out.println("4. List all currently available movies");
		System.out.println("5. View movies you currently have rented");
		System.out.print("Please enter your choice: ");
		choice = scanner.nextInt();
		switch (choice){
			case 1: System.out.print("Please enter the genre: ");
					 searchMovie("genre", scanner.next());
					 break;
			
			case 2: System.out.print("Please enter the title: ");
			 		 searchMovie("title", scanner.next());
					 break;
			
			case 3:
					System.out.print("Please enter the name (E.X. First,Last): ");
					searchMovie("person", scanner.next());
					break;
			
			case 4:
					listAllAvailableMovies();
					break;
			
			case 5: 
					viewRentedMovies();
					break;
			
			default: 
				showScreen();
				break;
					
		}
	}
	
	public static void searchMovie(String type, String name){
		/* Validate input */
		if (type.isEmpty() || name.isEmpty())
			throw new IllegalArgumentException("The parameters cannot be empty");
		
		String statement = "",
			   movieIDStatement = "",
			   actorIDStatement = "",
			   title = "",
			   price = "",
			   genre = "",
			   rating = "",
			   movieID = "",
			   actorID = "",
			   firstName = "",
			   lastName = "";
		
		
		if (type.equals("genre")){
			statement = "select distinct title, price, genre, movieid, rating from movies where genre = \'" + name + "\'";
			try{
				Statement stmt = con.createStatement();
				ResultSet rs = stmt.executeQuery(statement);
				System.out.println("=======Movies found with genre: " + name +"=======");
				while (rs.next()){
					System.out.println("=======movie ID: " + rs.getString("movieid") + "=======");
					System.out.println("Title:\t" + rs.getString("title"));
					System.out.println("Rating:\t" + rs.getInt("rating"));
					System.out.println("Price:\t" + rs.getInt("price"));
					System.out.println("Genre:\t" + rs.getString("Genre"));
					System.out.println("============================");
					System.out.println("");
				}
				rs.close();
			}
			catch (SQLException s){
				System.out.println(s.getMessage());
			}
		}
		else if (type.equals("title")){
			statement = "select distinct title, price, genre, rating, movieid from movies where title = \'" + name + "\'";
			try{
				Statement stmt = con.createStatement();
				ResultSet rs = stmt.executeQuery(statement);
				System.out.println("=======Movies found with title: " + name +"=======");
				while (rs.next()){
					System.out.println("=======movie ID: " + rs.getString("movieid") + "=======");
					System.out.println("Title:\t" + rs.getString("title"));
					System.out.println("Rating:\t" + rs.getInt("rating"));
					System.out.println("Price:\t" + rs.getInt("price"));
					System.out.println("Genre:\t" + rs.getString("Genre"));
					System.out.println("============================");
					System.out.println("");
				}
				rs.close();
				
			}
			catch (SQLException s){
				System.out.println(s.getMessage());
			}
		
		
		}
		else if (type.equals("person")){
			/* Isolate first and last name of actor */
			firstName = name.substring(0,name.indexOf(",")).trim();
			lastName = name.substring(name.indexOf(",") + 1, name.length()).trim();
			
			/* Get actor id */
			actorIDStatement = "select actorID from actors where first_Name = \'" + firstName + "\' and last_Name = \'" + lastName + "\'";
			try{
				Statement stmt = con.createStatement();
				ResultSet rs = stmt.executeQuery(actorIDStatement);
				while (rs.next()) {
					actorID = rs.getString("ACTORID");
				}
				//actorID = rs.getString("ACTORID");
				rs.close();
				System.out.println("=======Movies found for actor: " + firstName + " " + lastName + " " +actorID + "=======");
				statement = "select distinct title, rating, price, genre, movieid from movies join movieactors using(movieid) join actors using(actorid) where actorid = \'" + actorID + "\'";
				rs = stmt.executeQuery(statement);
				while (rs.next()){
					System.out.println("=======movie ID: " + rs.getString("movieid") + "=======");
					System.out.println("Title:\t" + rs.getString("title"));
					System.out.println("Rating:\t" + rs.getInt("rating"));
					System.out.println("Price:\t" + rs.getInt("price"));
					System.out.println("Genre:\t" + rs.getString("Genre"));
					System.out.println("============================");
					System.out.println("");
				}
				rs.close();
				
			}
			catch (SQLException s){
				System.out.println(s.getMessage());
			}
			
		}
		
	}
	
	public static void listAllAvailableMovies() {
		String statement = "select * from movies";
		try{
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(statement);
			System.out.println("=======Listing all movies=======");
			rs = stmt.executeQuery(statement);
			while (rs.next()){
				System.out.println("=======movie ID: " + rs.getString("movieid") + "=======");
				System.out.println("Title:\t" + rs.getString("title"));
				System.out.println("Rating:\t" + rs.getInt("rating"));
				System.out.println("Price:\t" + rs.getInt("price"));
				System.out.println("Genre:\t" + rs.getString("Genre"));
				System.out.println("============================");
				System.out.println("");
			}
			rs.close();
			
		}
		catch (SQLException s){
			System.out.println(s.getMessage());
		}
		
	}
	
	
	public static void viewRentedMovies() {
		
	}

}
